## KnowledgeHut JavaScript Starter Template

This template uses Parcel bundler. You can build your website in the src/ folder. Please all JavaScript in the src/js folder and all stylesheets in the src/css folder.

**Instructions**

- Development : `npm run dev`
- Production Build: `npm run build`
